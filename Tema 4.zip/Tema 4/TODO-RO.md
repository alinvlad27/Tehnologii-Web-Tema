#Subiect 3 (2.5 pts)
#TOPIC: REACT

# Dată fiind aplicația modificati codul sursă astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Se desenează o componentă RobotForm; (0.5 pts)
- RobotForm adaugă un robot cu proprietăți vide dacă se dă direct click pe butonul de `add`; (0.5 pts)
- Dat fiind că input-urile pentru proprietățile robotului au id-urile `name`, `type` and `mass` și că butonul de adăugare are valoarea `add` se poate adăuga un robot;(0.5 pts)
- Dacă se adaugă un robot cu `weight` mai mic de 500, elementul adăugat va avea `weight` în starea inițială(un string vid). (0.5 pts)