const compress = (str, compress = true) => {
	if (typeof str !== 'string' && !(str instanceof String)) {
	  throw new Error('InvalidType');
	}
  
	if (compress) {
	  // Implementarea compresiei RLEnpm test
	  let compressed = '';
	  let count = 1;
	  for (let i = 0; i < str.length; i++) {
		if (str[i] === str[i + 1]) {
		  count++;
		} else {
		  compressed += str[i] + count;
		  count = 1;
		}
	  }
	  return compressed;
	} else {
	  // Implementarea decompresiei RLE
	  let decompressed = '';
	  for (let i = 0; i < str.length; i += 2) {
		const char = str[i];
		const count = parseInt(str[i + 1]);
		if (isNaN(count)) {
		  throw new Error('InvalidType');
		}
		decompressed += char.repeat(count);
	  }
	  return decompressed;
	}
  };
  
module.exports = compress