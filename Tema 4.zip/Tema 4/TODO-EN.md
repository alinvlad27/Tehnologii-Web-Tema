#Subject 3 (2.5 pts)
#TOPIC: REACT

# Having the following application developed using React complete the project so that :

- The application renders without crashing; (0.5 pts)
- A RobotForm component is rendered; (0.5 pts)
- The RobotForm adds an empty record if the `add` button is clicked; (0.5 pts)
- Given that the inputs for the robot properties have the ids `name`, `type` and `mass` and that the add button has the value `add` a robot can be successfully added;(0.5 pts)
- If a robot with less than 500 weight is added, the value remains empty. (0.5 pts)